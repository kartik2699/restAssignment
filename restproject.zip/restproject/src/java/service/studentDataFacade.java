/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import stud.studentData;

/**
 *
 * @author Lenovo
 */
@Stateless
public class studentDataFacade extends AbstractFacade<studentData> {

    @PersistenceContext(unitName = "restprojectPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public studentDataFacade() {
        super(studentData.class);
    }
    
}
