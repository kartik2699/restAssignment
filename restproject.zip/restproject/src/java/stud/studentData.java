/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stud;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Lenovo
 */
@Entity
@XmlRootElement
public class studentData implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof studentData)) {
            return false;
        }
        studentData other = (studentData) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "stud.studentData[ id=" + id + " ]";
    }
    
        public int stud_no;

    /**
     * Get the value of stud_no
     *
     * @return the value of stud_no
     */
    public int getstud_no() {
        return stud_no;
    }

    /**
     * Set the value of stud_no
     *
     * @param stud_no new value of stud_no
     */
    public void setstud_no(int stud_no) {
        this.stud_no = stud_no;
    }

    public String name;

    /**
     * Get the value of name
     *
     * @return the value of name
     */
    public String getname() {
        return name;
    }

    /**
     * Set the value of name
     *
     * @param name new value of name
     */
    public void setname(String name) {
        this.name = name;
    }

        public String dob;

    /**
     * Get the value of dob
     *
     * @return the value of dob
     */
    public String getdob() {
        return dob;
    }

    /**
     * Set the value of dob
     *
     * @param dob new value of dob
     */
    public void setdob(String dob) {
        this.dob = dob;
    }

    
    public String doj;

    /**
     * Get the value of doj
     *
     * @return the value of doj
     */
    public String getdoj() {
        return doj;
    }

    /**
     * Set the value of doj
     *
     * @param doj new value of doj
     */
    public void setdoj(String doj) {
        this.doj = doj;
    }

    
    
}
